geojson 0.1.2
=============

### BUG FIXES

* Fixed bug in internal function that checked for existence
of a Suggested package (#17)


geojson 0.1.0
=============

### NEW FEATURES

* Released to CRAN.
