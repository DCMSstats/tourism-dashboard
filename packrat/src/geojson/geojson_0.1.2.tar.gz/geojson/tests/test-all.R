library("testthat")
library("geojson")
test_check("geojson")
