library("R.utils")

print(System$getHostname())
print(System$getUsername())
print(System$currentTimeMillis())

