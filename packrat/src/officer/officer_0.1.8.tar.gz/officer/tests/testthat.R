suppressPackageStartupMessages({
  library(testthat)
  library(officer)
  library(magrittr)
  library(dplyr)
  library(xml2)
})

test_check("officer")
