geojsonlint 0.2.0
=================

## NEW FEATURES

* Now using a new version of the JS library `geojsonhint` (`v2.0.0-beta2`)
(#9) - see `geojsonhint` Changelog for changes to the JS library:
<https://github.com/mapbox/geojsonhint/blob/master/CHANGELOG.md>


geojsonlint 0.1.0
=================

## NEW FEATURES

* released to CRAN
