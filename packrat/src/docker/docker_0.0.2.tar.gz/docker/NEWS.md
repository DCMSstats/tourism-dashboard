# docker 0.0.2

* Tests needed to be skipped on CRAN

# docker 0.0.1

* Initial version.
